<?php
header("Content-Type:application/json");
if (isset($_GET['svvId']) && $_GET['svvId']!="") {
 $con = mysqli_connect("localhost","shreyak", "test123","intern_db");
    if (mysqli_connect_errno()){
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 $un = $_GET['svvId'];

 $result = mysqli_query($con,"SELECT * FROM login_data WHERE svvId='$un'");
 if(mysqli_num_rows($result)>0){
 $row = mysqli_fetch_array($result);

 $user_id = $row['user_id'];
 $user_type = $row['user_type'];
 $svvId = $row['svvId'];

 response($user_id,$user_type,$svvId);

 mysqli_close($con);
 }else{
 response(NULL, NULL, NULL);
 }
}else{
 response(NULL, NULL, NULL);
 }
 
function response($user_id,$user_type,$svvId){
 $response['user_id'] = $user_id;
 $response['user_type'] = $user_type;
 $response['svvId'] = $svvId;

 $json_response = json_encode($response);
 echo $json_response;
}
?>