<?php
if (isset($_POST['order_id']) && $_POST['order_id']!="") {
 $order_id = $_POST['order_id'];
 $url = "http://localhost/100/7/api.php?order_id={$order_id}";
 
 $client = curl_init($url);
 curl_setopt($client,CURLOPT_RETURNTRANSFER,true);
 $response = curl_exec($client);
 
 $result = json_decode($response,true);
 $id = $result['order_id'];
 $price = $result['amount'];
 echo "<table>";
 echo "<tr><td>Order ID:</td><td>$id</td></tr>";
 echo "<tr><td>Amount:</td><td>$price</td></tr>";
  echo "</table>";
}
    ?>