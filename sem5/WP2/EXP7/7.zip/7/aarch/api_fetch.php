<?php
if (isset($_POST['svvId']) && $_POST['svvId']!="") {
 $svvId = $_POST['svvId'];
 //echo $svvId;
 $url = "http://localhost/wpfile/api_main.php?svvId=".$svvId;
 //echo $url;
 $client = curl_init($url);
 curl_setopt($client,CURLOPT_RETURNTRANSFER,true);
 $response = curl_exec($client);
 
 $result = json_decode($response,true);
 
 $user_id_fetch = $result['user_id'];
 $user_type_fetch = $result['user_type'];
 $svvId_fetch = $result['svvId'];


 echo "<table>";
 echo "<tr><td>User ID:</td><td>$user_id_fetch</td></tr>";
 echo "<tr><td>User Type:</td><td>$user_type_fetch</td></tr>";
 echo "<tr><td>svvId:</td><td>$svvId_fetch</td></tr>";
  echo "</table>";
}
    ?>