<?php
header("Content-Type:application/json");
if (isset($_GET['order_id']) && $_GET['order_id']!="") {
 $con = mysqli_connect("localhost","root","","100");
    if (mysqli_connect_errno()){
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 $order_id = $_GET['order_id'];
 $result = mysqli_query(
 $con,
 "SELECT * FROM product WHERE order_id=$order_id");
 if(mysqli_num_rows($result)>0){
 $row = mysqli_fetch_array($result);
 $amount = $row['amount'];
 response($order_id, $amount);
 mysqli_close($con);
 }else{
 response(NULL, NULL);
 }
}else{
 response(NULL, NULL);
 }
 
function response($order_id,$amount){
 $response['order_id'] = $order_id;
 $response['amount'] = $amount;
 $json_response = json_encode($response);
 echo $json_response;
}
?>