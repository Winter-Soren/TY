<?php
require_once __DIR__ . '/lib/DataSource.php';
$database = new DataSource();
$sql = "DELETE FROM students WHERE studentId =? ";
$paramType = "i";
$paramValue = array(
    $_GET["studentId"]
);
$database->delete($sql, $paramType, $paramValue);
header("Location:index.php");
exit();
?>