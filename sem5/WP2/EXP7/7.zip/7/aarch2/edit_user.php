<?php
require_once __DIR__ . '/lib/DataSource.php';
$database = new DataSource();

if (count($_POST) > 0) {
    $sql = "UPDATE students set branchName=?, svvId=? ,firstName=? ,lastName=? WHERE studentId=?";
    $paramType = 'ssssi';
    $paramValue = array(
        $_POST["signup-name"],
        $_POST["svvId"],
        $_POST["firstName"],
        $_POST["lastName"],
        $_GET["studentId"]
    );
    $database->execute($sql, $paramType, $paramValue);
    $message = "Record Modified Successfully";
}
$sql = "select * from students where studentId=? ";
$paramType = 'i';
$paramValue = array(
    $_GET["studentId"]
);
$result = $database->select($sql, $paramType, $paramValue);
?>
<html>
<head>
<title>Edit User</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/form.css" />
</head>
<body>
    <div class="phppot-container">
        <form name="frmUser" method="post" action="">
            <div class="message"><?php if(isset($message)) { echo $message; } ?></div>
            <p>
                <a href="index.php" class="font-bold"> List User</a>
            </p>
            <h1>Edit User</h1>
            <div>
                <div class="row">
                    <label for="signup-name">Branch Name <span
                        class="error-color" id="signup-name_error"></span>
                    </label><input type="text" name="signup-name"
                        id="signup-name"
                        value="<?php echo $result[0]['branchName']; ?>">
                </div>
            </div>
            <div class="row">
                <label>svvId</label> <input type="hidden"
                    name="studentId" class="txtField"
                    value="<?php echo $result[0]['studentId']; ?>"><input
                    type="text" name="svvId" class="txtField"
                    value="<?php echo $result[0]['svvId']; ?>">
            </div>
            <div class="row">
                <label>First Name</label> <input type="text"
                    name="firstName" class="txtField"
                    value="<?php echo $result[0]['firstName']; ?>">
            </div>
            <div class="row">
                <label>Last Name</label> <input type="text"
                    name="lastName" class="txtField"
                    value="<?php echo $result[0]['lastName']; ?>">
            </div>
            <div class="row">
                <input type="submit" name="submit" value="Save"
                    class="btnSubmit">
            </div>
        </form>
    </div>
</body>
</html>