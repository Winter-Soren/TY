CREATE TABLE `students` (
  `studentId` int(8) NOT NULL,
  `branchName` varchar(55) NOT NULL,
  `svvId` varchar(55) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL
);

ALTER TABLE `students`
  ADD PRIMARY KEY (`studentId`);

ALTER TABLE `students`
  MODIFY `studentId` int(8) NOT NULL AUTO_INCREMENT;
